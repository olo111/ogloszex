package pl.javastart.restoffers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestOffersApplication {

    public static void main(String[] args) {
        SpringApplication.run(RestOffersApplication.class, args);
    }
}

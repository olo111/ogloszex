package pl.javastart.restoffers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestOffersApplicationTests {

    @Test
    public void contextLoads() {
    }

}

package pl.javastart.restoffers.offer;

public class NoCategoryException extends RuntimeException {

    public NoCategoryException(String message) {
        super(message);
    }
}
